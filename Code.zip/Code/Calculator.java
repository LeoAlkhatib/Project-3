import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator extends JPanel implements ActionListener
{
    Left r = new Left();
    Calculation c = new Calculation();
    JButton b = new JButton("Back");
    JPanel pl = new JPanel();
    JPanel dummy = new JPanel();
    public Calculator(){
        constructGUI();
    }

    public void constructGUI(){
        setSize(750, 500);

        GridBagLayout gl = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        Insets insets = new Insets(0,0,0,0);

        setLayout( gl );

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 2;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = insets;
        add( r, gc);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = insets;
        add( c  , gc);
        
        gc.gridx = 1;     gc.gridy = 1;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 0.2;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = insets;
        dummy.setLayout(gl);
        add( dummy  , gc);

        insets = new Insets(0,0,0,20);
        
        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 0.2;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = insets;
        b.addActionListener(this);
        dummy.add( b  , gc);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 10;   gc.weighty = 0.2;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = insets;
        dummy.add( pl  , gc);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == b){
            setVisible(false);
            Main.getInstance().remove(this);
            Main.getInstance().add(Main.getInstance().loginscreen);
        }
    }
}
