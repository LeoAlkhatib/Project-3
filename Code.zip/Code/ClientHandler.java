import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class ClientHandler
{
    private ArrayList<Client> Clients;

    /**
     * The constructur
     */
    public ClientHandler(){

    }

    /**
     * The clients information is in the file in this form saved (NAME#PASSWORD) therefore we have to split
     * it into 2 strings to use them better.
     * This method splits the string into 2 strings and create a new client with the inforamtion 
     * we found from spliting the string.
     */
    public Client InfoClient(String line){
        String[] info = line.split("#");

        String name = info[0];
        String pass = info[1];

        Client client = new Client(name, pass);

        return client;
    }

    /**
     * This method reads a line from the file and uses the intern method InfoClient. And adds
     * client to the ArrayList clients. This method fills the ArrayList with clients.
     */
    public ArrayList<Client> Read(){
        String line = "";
        Clients = new ArrayList<>();
        Client client;
        try {
            FileReader reader = new FileReader("Accounts.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);

            line = bufferedReader.readLine();

            while(line != null){
                client = InfoClient(line);
                Clients.add(client);
                line = bufferedReader.readLine();
            }

            reader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return Clients;
    }

    /**
     * The method wrties lines in the file.
     * The lines are the clients information in the form (NAME#PASSWORD).
     */
    public void Write(String name, String pass){
        try {
            FileWriter writer = new FileWriter("Accounts.txt", true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);

            FileReader reader = new FileReader("Accounts.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line = bufferedReader.readLine();

            if(line == null){
                bufferedWriter.write(name);
                bufferedWriter.write("#");
                bufferedWriter.write(pass);
            } else {
                bufferedWriter.write("\n");
                bufferedWriter.write(name);
                bufferedWriter.write("#");
                bufferedWriter.write(pass);
            }

            bufferedWriter.close();
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void WriteInfo(String name, String pass, String info){
        try {
            FileWriter writer = new FileWriter("Accounts.txt", true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);

            bufferedWriter.write("\n");
            bufferedWriter.write(name);
            bufferedWriter.write("#");
            bufferedWriter.write(pass);

            bufferedWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method checks if a specific client is in the ArrayList from his name.
     */
    public boolean FindClient(String name){
        boolean found = false;
        ArrayList<Client> Clients = new ArrayList<>();
        Clients = Read();
        for(Client c: Clients){
            if(c.getName().equals(name)){
                found = true;
                break;
            }
            else {
                found = false;
            }
        }
        return found;
    }

    public void Delete(){
        try
        {
            new FileWriter("Accounts.txt", false).close();
        }
        catch (IOException ioe)
        {
            ioe.printStackTrace();
        }
    }

    public void Print(){
        for(Client c: Clients){
            System.out.println(c.getName() + ", " + c.getPassword());
        }
    }
}
