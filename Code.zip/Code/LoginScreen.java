import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;
import java.util.ArrayList;
import javax.swing.ImageIcon;

public class LoginScreen extends JPanel implements ActionListener{

    private JPanel plUsername, plDuserr;
    private JTextField tfUsername;
    private JLabel lbUsername;

    private JPanel plPass, plDpass;
    private JPasswordField tfPass;
    private JLabel lbPass;

    private JPanel plBtns, plDbtns;
    private JButton btnLogin, btnCl;

    private JPanel plSignUp, plDs;
    private JButton btnSignUp;
    private JLabel lbSignup;

    private JPanel plButtom, plLeft, plTop;

    private ArrayList<Client> Clients;

    private JLabel lb;
    private JPanel pl, plDummy;
    private ImageIcon image;

    private Client currentClient;

    private JPanel plPrb;
    private JProgressBar prgBar;

    private Timer timer;
    
    private int progress = 0;

    /**
     * Create the frame.
     */
    public LoginScreen() {
        GridBagLayout gl = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        Insets inset = new Insets(0,0,0,0);

        setLayout(gl);

        inset = new Insets(100,0,0,0);
        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plUsername = new JPanel();
        //this.plUsername.setBackground(Color.PINK);
        this.plUsername.setLayout(gl);
        add( this.plUsername, gc);

        inset = new Insets(0,70,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.lbUsername = new JLabel("username:");
        this.lbUsername.setFont(new Font("Bahnschrift", Font.PLAIN, 15));
        this.plUsername.add( this.lbUsername, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 70;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.tfUsername = new JTextField();
        this.plUsername.add( this.tfUsername, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 150;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plDuserr = new JPanel();
        //this.plDuserr.setBackground(Color.black);
        this.plUsername.add( this.plDuserr, gc);

        /** ************************************************/ 
        gc.gridx = 1;     gc.gridy = 1;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plPass = new JPanel();
        //this.plPass.setBackground(Color.PINK);
        this.plPass.setLayout(gl);
        add( this.plPass, gc);

        inset = new Insets(0,70,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.lbPass = new JLabel("password:");
        this.lbPass.setFont(new Font("Bahnschrift", Font.PLAIN, 15));
        this.plPass.add( this.lbPass, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 70;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.tfPass = new JPasswordField();
        this.plPass.add( this.tfPass, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 150;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plDpass = new JPanel();
        //this.plDuserr.setBackground(Color.black);
        this.plPass.add( this.plDpass, gc);

        /********************************************************** */

        gc.gridx = 1;     gc.gridy = 2;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plBtns = new JPanel();
        //this.plBtns.setBackground(Color.PINK);
        this.plBtns.setLayout(gl);
        add( this.plBtns, gc);

        inset = new Insets(0,70,0,0);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.btnLogin = new JButton("Log in");
        this.btnLogin.setBackground(Color.LIGHT_GRAY);
        this.btnLogin.addActionListener(this);
        this.plBtns.add( this.btnLogin, gc);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.btnCl = new JButton("Clear");
        this.btnCl.setBackground(Color.LIGHT_GRAY);
        this.btnCl.addActionListener(this);
        this.plBtns.add( this.btnCl, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 5;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plDbtns = new JPanel();
        //this.plDbtns.setBackground(Color.black);
        this.plBtns.add( this.plDbtns, gc);

        /** **********************************************/

        inset = new Insets(50,0,0,0);
        gc.gridx = 1;     gc.gridy = 3;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plSignUp = new JPanel();
        //this.plSignUp.setBackground(Color.red);
        this.plSignUp.setLayout(gl);
        add( this.plSignUp, gc);

        inset = new Insets(0,70,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.btnSignUp = new JButton("Sign up");
        this.btnSignUp.addActionListener(this);
        this.btnSignUp.setBackground(Color.LIGHT_GRAY);
        this.plSignUp.add( this.btnSignUp, gc);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.lbSignup = new JLabel("You don't have an account?");
        this.lbSignup.setFont(new Font("Bahnschrift", Font.PLAIN, 15));
        this.plSignUp.add( this.lbSignup, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 8;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plDs = new JPanel();
        //this.plDs.setBackground(Color.black);
        this.plSignUp.add( this.plDs, gc);

        /*** *****************************************/

        gc.gridx = 1;     gc.gridy = 5;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 10;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.plButtom = new JPanel();
        //this.plButtom.setBackground(Color.PINK);
        add( this.plButtom, gc);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 6;
        gc.weightx = 1;   gc.weighty = 10;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.plLeft = new JPanel();
        this.plLeft.setLayout(gl);
        this.plLeft.setBackground(new Color(29, 42, 117));
        add( this.plLeft, gc);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 7;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.pl = new JPanel();
        this.pl.setLayout(gl);
        this.pl.setBackground(new Color(29, 42, 117));
        this.plLeft.add(this.pl, gc);

        gc.gridx = 0;     gc.gridy = 1;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 10;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.plDummy = new JPanel();
        this.plDummy.setBackground(new Color(29, 42, 117));
        this.plLeft.add(this.plDummy, gc);

        this.lb = new JLabel();
        this.image = new ImageIcon("diet2.png");
        this.lb.setIcon(image);
        this.plDummy.add(this.lb, gc);

        /******************************************************/
        gc.gridx = 0;     gc.gridy = 6;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.plPrb = new JPanel();
        this.plPrb.setLayout(gl);
        this.plPrb.setBackground(Color.PINK);
        add( this.plPrb, gc);

        gc.gridx = 0;     gc.gridy = 6;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.prgBar = new JProgressBar();
        this.prgBar.setValue(0);
        this.prgBar.setBackground(Color.white);
        this.prgBar.setForeground(Color.green);
        this.plPrb.add(this.prgBar, gc);

    }

    public void fill() {
        short counter = 0;
        while(counter <= 100)
        {
            this.prgBar.setValue(counter);

            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {

                e.printStackTrace();
            }

            counter++;
        }
        this.repaint();
    }

    private void startProgressBar() {
        btnLogin.setEnabled(false);
        int progress = 0;
        prgBar.setValue(progress);

        timer = new Timer(100, this);
        timer.start();
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == btnSignUp){
            Main.getInstance().remove(Main.getInstance().loginscreen);
            Main.getInstance().add(Main.getInstance().createBenutzer);

            Main.getInstance().revalidate();
            Main.getInstance().repaint();
        }
        else if(e.getSource() == btnLogin)
        {
            ClientHandler c = new ClientHandler();

            Clients = c.Read();

            boolean foundN = false;
            boolean foundP = false;
            String foundName = "";

            for(Client cl: Clients){

                String name = tfUsername.getText();

                if(cl.getName().equals(name)){
                    foundN = true;
                    currentClient = cl;
                }
            }

            if(foundN){
                String pass = currentClient.getPassword();

                if(tfPass.getText().equals(pass)){
                    foundP = true;
                }
            }

            if(tfUsername.getText().equals("") && tfPass.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Please make sure to enter the rquiered information: username, password" , "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if(foundN == false){
                JOptionPane.showMessageDialog(null,"This username doesn't exist" , "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if(foundN == true && tfPass.getText().equals("")){
                JOptionPane.showMessageDialog(null,"You may have forget to enter the password" , "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if(foundN == true && foundP == false){
                JOptionPane.showMessageDialog(null,"You may have entered a wrong password" , "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if(foundN == true && foundP == true){
                startProgressBar();
            }
        }
        else if(e.getSource() == btnCl){
            tfPass.setText("");
            tfUsername.setText("");
        } 
        else if(e.getSource() == this.timer){
            progress += 25;
            prgBar.setValue(progress);
            if (progress >= 100) {
                this.timer.stop();
                btnLogin.setEnabled(true);
                Main.getInstance().remove(Main.getInstance().loginscreen);
                Main.getInstance().add(new Calculator());

                Main.getInstance().revalidate();
                Main.getInstance().repaint();

                tfPass.setText("");
                tfUsername.setText("");
                
                progress = 0;
                prgBar.setValue(progress);
            } 
        }
    }
} 

