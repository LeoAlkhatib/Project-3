import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class CreateUser extends JPanel implements ActionListener
{
    private JButton btnBack;

    private JPanel plUsername, plDuserr;
    private JTextField tfUsername;
    private JLabel lbUsername;

    private JPanel plPass, plDpass;
    private JPasswordField tfPass;
    private JLabel lbPass;

    private JPanel plPassRep, plDpassRep;
    private JPasswordField tfPassRep;
    private JLabel lbPassRep;

    private JPanel plBtns, plDbtns;
    private JButton btnLogin, btnCl;

    private JPanel plSignUp, plDs;
    private JButton btnSignUp;
    private JLabel lbSignup;

    private JPanel plButtom, plLeft, plTop;

    private ArrayList<Client> Clients;
    
    private JPanel plDummy, pl;
    private JLabel lb;
    private ImageIcon image;

    /**
     * Create the panel.
     */
    public CreateUser() {
        GridBagLayout gl = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        Insets inset = new Insets(0,0,0,0);

        setLayout(gl);

        inset = new Insets(100,0,0,0);
        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plUsername = new JPanel();
        //this.plUsername.setBackground(Color.PINK);
        this.plUsername.setLayout(gl);
        add( this.plUsername, gc);

        inset = new Insets(0,70,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.lbUsername = new JLabel("username:            ");
        this.lbUsername.setFont(new Font("Bahnschrift", Font.PLAIN, 15));
        this.plUsername.add( this.lbUsername, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 70;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.tfUsername = new JTextField();
        this.plUsername.add( this.tfUsername, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 150;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plDuserr = new JPanel();
        //this.plDuserr.setBackground(Color.black);
        this.plUsername.add( this.plDuserr, gc);

        /** ************************************************/ 
        gc.gridx = 1;     gc.gridy = 1;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plPass = new JPanel();
        //this.plPass.setBackground(Color.PINK);
        this.plPass.setLayout(gl);
        add( this.plPass, gc);

        inset = new Insets(0,70,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.lbPass = new JLabel("password:            ");
        this.lbPass.setFont(new Font("Bahnschrift", Font.PLAIN, 15));
        this.plPass.add( this.lbPass, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 70;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.tfPass = new JPasswordField();
        this.plPass.add( this.tfPass, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 150;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plDpass = new JPanel();
        //this.plDuserr.setBackground(Color.black);
        this.plPass.add( this.plDpass, gc);

        /********************************************************** */

        gc.gridx = 1;     gc.gridy = 2;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plPassRep = new JPanel();
        //this.plPass.setBackground(Color.PINK);
        this.plPassRep.setLayout(gl);
        add( this.plPassRep, gc);

        inset = new Insets(0,70,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.lbPassRep = new JLabel("repeat password:");
        this.lbPassRep.setFont(new Font("Bahnschrift", Font.PLAIN, 15));
        this.plPassRep.add( this.lbPassRep, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 70;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.tfPassRep = new JPasswordField();
        this.plPassRep.add( this.tfPassRep, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 150;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plDpassRep = new JPanel();
        //this.plDuserr.setBackground(Color.black);
        this.plPassRep.add( this.plDpassRep, gc);

        /** *****************************************/

        gc.gridx = 1;     gc.gridy = 3;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plBtns = new JPanel();
        //this.plBtns.setBackground(Color.PINK);
        this.plBtns.setLayout(gl);
        add( this.plBtns, gc);

        inset = new Insets(0,70,0,0);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.btnSignUp = new JButton("Sign up");
        this.btnSignUp.addActionListener(this);
        this.btnSignUp.setBackground(Color.LIGHT_GRAY);
        this.plBtns.add( this.btnSignUp, gc);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.btnCl = new JButton("Clear");
        this.btnCl.addActionListener(this);
        this.btnCl.setBackground(Color.LIGHT_GRAY);
        this.plBtns.add( this.btnCl, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 5;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plDbtns = new JPanel();
        //this.plDbtns.setBackground(Color.black);
        this.plBtns.add( this.plDbtns, gc);

        /** **********************************************/

        inset = new Insets(50,0,0,0);
        gc.gridx = 1;     gc.gridy = 4;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plSignUp = new JPanel();
        //this.plSignUp.setBackground(Color.red);
        this.plSignUp.setLayout(gl);
        add( this.plSignUp, gc);

        inset = new Insets(0,70,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.btnLogin = new JButton("Log in");
        this.btnLogin.addActionListener(this);
        this.btnLogin.setBackground(Color.LIGHT_GRAY);
        this.plSignUp.add( this.btnLogin, gc);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.lbSignup = new JLabel("You already have an account?");
        this.lbSignup.setFont(new Font("Bahnschrift", Font.PLAIN, 15));
        this.plSignUp.add( this.lbSignup, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 8;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plDs = new JPanel();
        //this.plDs.setBackground(Color.black);
        this.plSignUp.add( this.plDs, gc);

        /*** *****************************************/

        gc.gridx = 1;     gc.gridy = 5;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 10;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.plButtom = new JPanel();
        //this.plButtom.setBackground(Color.PINK);
        add( this.plButtom, gc);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 6;
        gc.weightx = 1;   gc.weighty = 10;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.plLeft = new JPanel();
        this.plLeft.setLayout(gl);
        this.plLeft.setBackground(new Color(29, 42, 117));
        add( this.plLeft, gc);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 7;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.pl = new JPanel();
        this.pl.setBackground(new Color(29, 42, 117));
        this.plLeft.add(this.pl, gc);

        gc.gridx = 0;     gc.gridy = 1;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 10;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.plDummy = new JPanel();
        this.plDummy.setBackground(new Color(29, 42, 117));
        this.plLeft.add(this.plDummy, gc);

        this.lb = new JLabel();
        this.image = new ImageIcon("diet2.png");
        this.lb.setIcon(image);
        this.plDummy.add(this.lb, gc);

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource().equals(btnLogin))
        {
            Main.getInstance().remove(Main.getInstance().createBenutzer);
            Main.getInstance().add(Main.getInstance().loginscreen);

            Main.getInstance().revalidate();
            Main.getInstance().repaint();
        }
        else if(e.getSource().equals(btnSignUp))
        {
            /* find errors if there is and save it in a string to display it once */
            String error = "";
            if(tfUsername.getText().equals("")){
                error += "\n# You may have forget to enter your username";
            }
            if(tfPass.getText().equals("")){
                error += "\n# Please enter a password";
            }
            if(!tfPassRep.getText().equals(tfPass.getText())){
                if(tfPassRep.getText().equals("")){
                    error += "\n# Please make sure to repeat your password";
                }
                else {
                    error += "\n# You may have repeated your password wrong";
                }
            }
            if(!error.equals("")){ /* display errors if there is any */
                JOptionPane.showMessageDialog(null,error , "Error", JOptionPane.ERROR_MESSAGE);
            }
            else { /* if there is no error, save the names in the file */
                ClientHandler c = new ClientHandler();
                String name = tfUsername.getText();
                String pass = tfPass.getText();
                boolean thereIs = c.FindClient(name);
                if(thereIs == true){ /* check if the name is already in the sysytem */
                    JOptionPane.showMessageDialog(null,"This name is already in the system" , "Error", JOptionPane.ERROR_MESSAGE);
                }
                else {
                    c.Write(name, pass);
                    JOptionPane.showMessageDialog(null,"You are now in the system!" , "Information", JOptionPane.INFORMATION_MESSAGE);

                    Main.getInstance().remove(Main.getInstance().createBenutzer);
                    Main.getInstance().add(Main.getInstance().loginscreen);

                    Main.getInstance().revalidate();
                    Main.getInstance().repaint();
                }
            }
        } else if(e.getSource() == btnCl){
            tfPass.setText("");
            tfPassRep.setText("");
            tfUsername.setText("");
        }
    }
}

