import javax.swing.*;

public class Main extends JFrame
{
    public LoginScreen loginscreen;
    public CreateUser createBenutzer;
    private static Main instance;
    public static void main(String[] args) {
        new ClientHandler();
        new Main();
    }

    public Main() {
        super("Calculator");
        instance = this;
        setSize(750, 500);

        loginscreen = new LoginScreen();
        createBenutzer = new CreateUser();


        add(loginscreen);


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static Main getInstance() {
        return instance;
    }
}
