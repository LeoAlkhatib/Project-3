import javax.swing.*;
import java.awt.*;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Write a description of class Calculation here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Calculation extends JPanel implements ActionListener{
    private JPanel plTop, plButtom, plR, plDrbtn, plDhei, plDw, plDa, plDres, plDbtns, plDacv, plH, plW, plA, plRes, plRbtn, plBtns, plAcv;
    private JComboBox cbCh, cbAcv;
    private JRadioButton rbtnM, rbtnF;
    private JLabel lbGender, lbHeight, lbWeight, lbAge, lbRes; 
    private JTextField tfHeight, tfWeight, tfRes;
    private JSpinner spAge;
    private JButton btnCal, btnCl;
    private int currentElement;
    private double cal, weightMac;

    private JPanel plCarb, plPro, plFat, plRes3, plBtn;
    private JPanel plDc, plDp, plDf, plDr, plButtom3, plDRes3, plDbtn;
    private JTextField tfCarb, tfPro, tfFat, tfRes3;
    private JButton btnCal3;
    private JLabel lbCarb, lbPro, lbFat, lbRes3;

    private GridBagConstraints gc = new GridBagConstraints();
    private GridBagLayout gl = new GridBagLayout();
    private Insets inset = new Insets(0,0,0,0);

    private String error = "";
    private double bmr = 0;

    private ButtonGroup group = new ButtonGroup();
    public Calculation(){
        setLayout(gl);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plTop = new JPanel();
        //this.plTop.setBackground(Color.GRAY);
        add( this.plTop, gc);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        String[] whatCal = {"Calories Calculator","Macros"};
        this.cbCh = new JComboBox(whatCal);
        this.cbCh.addActionListener(this);
        this.plTop.add(cbCh, gc);
        /** ========================================================================= */
        createComponents();
        /** ====================================================================================*/
        cbCh.setSelectedIndex(0);
        //setBackground(Color.blue);
    }

    public void createComponents(){
        /** calories calculator components */
        this.lbGender = new JLabel("Gender:");
        this.rbtnM = new JRadioButton("male");
        this.rbtnF = new JRadioButton("female");
        this.plDrbtn = new JPanel();
        this.plH = new JPanel();
        this.lbHeight = new JLabel("Height:");
        this.tfHeight = new JTextField();
        this.plDhei = new JPanel();
        this.plW = new JPanel();
        this.lbWeight = new JLabel("Weight:");
        this.tfWeight = new JTextField();
        this.plDw = new JPanel();
        this.plA = new JPanel();
        this.lbAge = new JLabel("Age:      ");
        this.spAge = new JSpinner();
        this.plDa = new JPanel();
        this.plAcv = new JPanel();
        String[] activeelements = {"Sedentary (little or no exercise)", "Lightly active (exercise 1–3 days/week)",
                "Moderately active (exercise 3–5 days/week)", "Active (exercise 6–7 days/week)", 
                "Very active (hard exercise 6–7 days/week)"};
        this.cbAcv = new JComboBox(activeelements);
        this.plDacv = new JPanel();
        this.plBtns = new JPanel();
        this.btnCal = new JButton("Claculate");
        this.btnCl = new JButton("Clear");
        this.plDbtns = new JPanel();
        this.plRes = new JPanel();
        this.lbRes = new JLabel("The calories you burn in a day:");
        this.tfRes = new JTextField();
        this.plDres = new JPanel();
        this.plButtom = new JPanel();
        /** ========================================================================================*/
        /** macros components */
        this.plCarb = new JPanel();
        this.plPro = new JPanel();
        this.plFat = new JPanel();
        this.plRes3 = new JPanel();
        this.plBtn = new JPanel();

        this.btnCal3 = new JButton("Calculate");

        this.lbCarb = new JLabel("Carbs:  ");
        this.lbPro = new JLabel("Protein:");
        this.lbFat = new JLabel("Fat:        ");
        this.lbRes3 = new JLabel("Your calculated calories");

        this.plDc = new JPanel();
        this.plDp = new JPanel();
        this.plDf = new JPanel();
        this.plDr = new JPanel();
        this.plDRes3 = new JPanel();
        this.plDbtn = new JPanel();

        this.tfCarb = new JTextField();
        this.tfPro = new JTextField();
        this.tfFat = new JTextField();
        this.tfRes3 = new JTextField();

        this.plButtom3 = new JPanel();
    }

    public void addCal(){
        gc.gridx = 0;     gc.gridy = 2;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plRbtn = new JPanel();
        this.plRbtn.setLayout(gl);
        //this.plRbtn.setBackground(Color.WHITE);
        add( this.plRbtn, gc);

        inset = new Insets(0,40,0,0);   

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plRbtn.add( this.lbGender, gc);

        inset = new Insets(0,20,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.rbtnM.addActionListener(this);
        this.plRbtn.add( this.rbtnM, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.rbtnF.addActionListener(this);
        this.plRbtn.add( this.rbtnF, gc);

        group.add(this.rbtnF);
        group.add(this.rbtnM);

        inset = new Insets(0,0,0,0);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 100;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDrbtn.setBackground(Color.WHITE);
        this.plRbtn.add(this.plDrbtn, gc);
        /** ========================================================================= */
        gc.gridx = 0;     gc.gridy = 3;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plH.setBackground(Color.PINK);
        this.plH.setLayout(gl);
        add( this.plH, gc);

        inset = new Insets(0,40,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plH.add( this.lbHeight, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 40;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plH.add( this.tfHeight, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 150;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDhei.setBackground(Color.black);
        this.plH.add( this.plDhei, gc);
        /** ========================================================================= */
        gc.gridx = 0;     gc.gridy = 4;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plW.setBackground(Color.PINK);
        this.plW.setLayout(gl);
        add( this.plW, gc);

        inset = new Insets(0,40,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plW.add( this.lbWeight, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 40;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plW.add( this.tfWeight, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 150;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDw.setBackground(Color.orange);
        this.plW.add( this.plDw, gc);
        /** ========================================================================= */
        gc.gridx = 0;     gc.gridy = 5;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plA.setBackground(Color.PINK);
        this.plA.setLayout(gl);
        add( this.plA, gc);

        inset = new Insets(0,40,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plA.add( this.lbAge, gc);

        inset = new Insets(0,0,0,0);        

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 40;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plA.add( this.spAge, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 170;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDa.setBackground(Color.black);
        this.plA.add( this.plDa, gc);
        /** ========================================================================= */
        gc.gridx = 0;     gc.gridy = 6;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plAcv.setBackground(Color.PINK);
        this.plAcv.setLayout(gl);
        add( this.plAcv, gc);

        inset = new Insets(0,40,0,0);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;

        this.cbAcv.addActionListener(this);
        this.plAcv.add( this.cbAcv, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 10;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDacv.setBackground(Color.black);
        this.plAcv.add( this.plDacv, gc);
        /** ========================================================================= */
        gc.gridx = 0;     gc.gridy = 7;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plBtns.setBackground(Color.PINK);
        this.plBtns.setLayout(gl);
        add( this.plBtns, gc);

        inset = new Insets(0,40,0,0);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.btnCal.addActionListener(this);
        this.btnCal.setBackground(Color.LIGHT_GRAY);
        this.plBtns.add( this.btnCal, gc);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.btnCl.addActionListener(this);
        this.btnCl.setBackground(Color.LIGHT_GRAY);
        this.plBtns.add( this.btnCl, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 5;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDbtns.setBackground(Color.black);
        this.plBtns.add( this.plDbtns, gc);
        /** ========================================================================= */
        gc.gridx = 0;     gc.gridy = 8;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plRes.setBackground(Color.PINK);
        this.plRes.setLayout(gl);
        add( this.plRes, gc);

        inset = new Insets(0,40,0,5);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plRes.add( this.lbRes, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 40;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plRes.add( this.tfRes, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 80;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDres.setBackground(Color.black);
        this.plRes.add( this.plDres, gc);
        /** ========================================================================= */
        gc.gridx = 0;     gc.gridy = 9;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 5;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        //this.plButtom.setBackground(Color.PINK);
        add( this.plButtom, gc);
        /** ========================================================================= */
    }

    public void addMacros(){
        gc.gridx = 0;     gc.gridy = 1;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plH.setBackground(Color.PINK);
        this.plRes3.setLayout(gl);
        add( this.plRes3, gc);

        inset = new Insets(0,40,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plRes3.add( this.lbRes3, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 40;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plRes3.add( this.tfRes3, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 80;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDres.setBackground(Color.black);
        this.plRes3.add( this.plDRes3, gc);

        /** ============================================ */
        gc.gridx = 0;     gc.gridy = 2;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plH.setBackground(Color.PINK);
        this.plBtn.setLayout(gl);
        add( this.plBtn, gc);

        inset = new Insets(0,40,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.btnCal3.addActionListener(this);
        this.btnCal3.setBackground(Color.LIGHT_GRAY);
        this.plBtn.add( this.btnCal3, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 40;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plBtn.add( this.plDbtn, gc);
        /** ============================================ */
        gc.gridx = 0;     gc.gridy = 3;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plH.setBackground(Color.PINK);
        this.plCarb.setLayout(gl);
        add( this.plCarb, gc);

        inset = new Insets(0,40,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plCarb.add( this.lbCarb, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 40;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.tfCarb.setEditable(false);
        this.plCarb.add( this.tfCarb, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 150;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDhei.setBackground(Color.black);
        this.plCarb.add( this.plDc, gc);
        /** ========================================================================= */
        gc.gridx = 0;     gc.gridy = 4;
        gc.gridwidth = 2; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plW.setBackground(Color.PINK);
        this.plPro.setLayout(gl);
        add( this.plPro, gc);

        inset = new Insets(0,40,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plPro.add( this.lbPro, gc);

        inset = new Insets(0,0,0,0);

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 40;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.tfPro.setEditable(false);
        this.plPro.add( this.tfPro, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 150;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDw.setBackground(Color.orange);
        this.plPro.add( this.plDp, gc);
        /** ========================================================================= */
        gc.gridx = 0;     gc.gridy = 5;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plA.setBackground(Color.PINK);
        this.plFat.setLayout(gl);
        add( this.plFat, gc);

        inset = new Insets(0,40,0,5);
        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.plFat.add( this.lbFat, gc);

        inset = new Insets(0,0,0,0);        

        gc.gridx = 1;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 40;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        this.tfFat.setEditable(false);
        this.plFat.add( this.tfFat, gc);

        gc.gridx = 2;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 150;   gc.weighty = 1;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = inset;
        //this.plDa.setBackground(Color.black);
        this.plFat.add( this.plDf, gc);
        /** ========================================================================= */
        gc.gridx = 0;     gc.gridy = 6;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 7;
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        //this.plButtom3.setBackground(Color.PINK);
        add( this.plButtom3, gc);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == cbCh){
            currentElement = cbCh.getSelectedIndex();

            if(currentElement == 0){
                addCal();
                this.revalidate();
                this.repaint();
            } else if(currentElement == 1 && cal != 0){
                addMacros();
                this.revalidate();
                this.repaint(); 
            } 

            if(currentElement != 0){
                tfHeight.setText("");
                tfWeight.setText("");
                tfRes.setText("");
                group.clearSelection();
                spAge.setValue(Integer.valueOf(0));
                this.remove(this.plRbtn);
                this.remove(this.plH);
                this.remove(this.plW);
                this.remove(this.plA);
                this.remove(this.plAcv);
                this.remove(this.plBtns);
                this.remove(this.plRes);
                this.remove(this.plButtom);
                this.revalidate();
                this.repaint();
            } else if(currentElement != 1){
                tfPro.setText("");
                tfCarb.setText("");
                tfFat.setText("");
                tfRes3.setText("");
                this.remove(this.plBtn);
                this.remove(this.plCarb);
                this.remove(this.plPro);
                this.remove(this.plFat);
                this.remove(this.plRes3);
                this.remove(this.plButtom3);
                this.revalidate();
                this.repaint();
            }
        }
        else if(e.getSource() == btnCal && this.error.equals("")){
            if(!rbtnM.isSelected() && !rbtnF.isSelected()){
                error += "\n# You have forgotten to choose your gender";
            }
            if(tfHeight.getText().equals("")){
                error += "\n# You didn't enter your height";
            }
            if(tfWeight.getText().equals("")){
                error += "\n# You didn't enter your weight";
            }
            if(String.valueOf(spAge.getValue()).equals("")){
                error += "\n# You didn't enter your age";
            }

            if(!this.error.equals("")){
                JOptionPane.showMessageDialog(null,error , "Error", JOptionPane.ERROR_MESSAGE);
                error = "";
            } else if(this.error.equals("")){
                if(e.getSource() == btnCal && rbtnM.isSelected()){
                    if(!tfHeight.equals("") || !spAge.equals("") || !tfWeight.equals("")){
                        double height = Double.parseDouble(tfHeight.getText());
                        double weight = Double.parseDouble(tfWeight.getText());
                        weightMac = weight;
                        String tempAge = String.valueOf(spAge.getValue());
                        int age = Integer.parseInt(tempAge);
                        if(age < 15 || age > 80){
                            JOptionPane.showMessageDialog(null,"Please enter an age between 15-80" , "Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            bmr = (88.4 + (13.4 * weight)) + (4.8 * height) - (5.68 * age);
                            int currentItem = cbAcv.getSelectedIndex();
                            switch (currentItem){
                                case 0:
                                    bmr *= 1.2;
                                    break;
                                case 1:
                                    bmr *= 1.375;
                                    break;
                                case 2:
                                    bmr *= 1.55;
                                    break;
                                case 3:
                                    bmr *= 1.725;
                                    break;
                                case 4:
                                    bmr *= 1.9;
                                    break;

                            }
                            cal = Math.round(bmr);
                            tfRes.setText(Double.toString(cal));
                        }
                    }
                }
                else if(e.getSource() == btnCal && rbtnF.isSelected()){
                    double height = Double.parseDouble(tfHeight.getText());
                    double weight = Double.parseDouble(tfWeight.getText());
                    weightMac = weight;
                    String tempAge = String.valueOf(spAge.getValue());
                    int age = Integer.parseInt(tempAge);
                    if(age < 15 || age > 80){
                        JOptionPane.showMessageDialog(null,"Please enter an age between 15-80" , "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        bmr = (447.6 + (9.25 * weight)) + (3.10 * height) - (4.33 * age);
                        int currentItem = cbAcv.getSelectedIndex();
                        switch (currentItem){
                            case 0:
                                bmr *= 1.2;
                                break;
                            case 1:
                                bmr *= 1.375;
                                break;
                            case 2:
                                bmr *= 1.55;
                                break;
                            case 3:
                                bmr *= 1.725;
                                break;
                            case 4:
                                bmr *= 1.9;
                                break;

                        }
                        bmr = Math.round(bmr);
                        cal = bmr;
                        tfRes.setText(Double.toString(cal));
                    }
                }
            }
        }
        else if(e.getSource() == btnCl){
            tfHeight.setText("");
            tfWeight.setText("");
            tfRes.setText("");
            group.clearSelection();
            spAge.setValue(Integer.valueOf(0));
        }

        if(currentElement == 1){
            if(cal != 0){
                tfRes3.setText(Double.toString(cal));
                if(e.getSource() == btnCal3){
                    double proteinAm = weightMac * 2    ; // calculate the protein amount in g
                    tfPro.setText(Double.toString(proteinAm) + " g"); // set it in the text field

                    double proteinCal = proteinAm * 4; // calculate the calories for the protein

                    double fatCal = (cal * 25) / 100; // calcualte the calories for the fat
                    double fatAm = Math.round(fatCal / 9); // calculate the fat amount in g
                    tfFat.setText(Double.toString(fatAm) + " g"); // set it in the text field

                    // to calculate the carbs amount and its calorie we add protein and fat calorie and substract it from the original number of calorie
                    double carbCal = cal - (proteinCal + fatCal);
                    double carbAm = Math.round(carbCal / 4); // calcualte the carbs amount in g
                    tfCarb.setText(Double.toString(carbAm) + " g"); // set it in the text field
                }
            } 
            else {
                JOptionPane.showMessageDialog(null,"Please make sure calculate your calories first!" , "Error", JOptionPane.ERROR_MESSAGE);
            }
        } 
    }
}

