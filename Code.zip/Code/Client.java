
public class Client
{
    private String name, password, calories, bmr, idealWeight;
    
    public Client(String name, String password){
        this.name = name;
        this.password = password;
    }
    
    public String getName(){
        return name;
    }
    
    public String getPassword(){
        return password;
    }
    
    public String getCalories(){
        return calories;
    }
    
    public String getBMR(){
        return bmr;
    }
    
    public String getIdealWeight(){
        return idealWeight;
    }
    
    public void setCalories(String info){
        calories = info;
    }
    
    public void setBMR(String info){
         bmr = info;
    }
    
    public void setIdealWeight(String info){
         idealWeight = info;
    }
}
