import javax.swing.*;
import java.awt.*;

public class Left extends JPanel{
    private JLabel lb;
    private JPanel pl, plDummy;
    private ImageIcon image;
    public Left(){
        setBackground(new Color(29, 42, 117));

        GridBagLayout gl = new GridBagLayout();
        GridBagConstraints gc = new GridBagConstraints();
        Insets inset = new Insets(0,0,0,0);

        setLayout(gl);

        gc.gridx = 0;     gc.gridy = 0;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 7;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.pl = new JPanel();
        this.pl.setLayout(gl);
        this.pl.setBackground(new Color(29, 42, 117)); 
        add(this.pl, gc);

        gc.gridx = 0;     gc.gridy = 1;
        gc.gridwidth = 1; gc.gridheight = 1;
        gc.weightx = 1;   gc.weighty = 10;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = inset;
        this.plDummy = new JPanel();
        this.plDummy.setBackground(new Color(29, 42, 117));
        add(this.plDummy, gc);

        this.lb = new JLabel();
        this.image = new ImageIcon("diet2.png");
        this.lb.setIcon(image);
        this.plDummy.add(this.lb, gc);
    }
}
